print('Hello, Python')
